from django.apps import AppConfig


class ToolkitappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ToolkitApp'